const { createBrokerAdapter } = require('../../broker');

class BrokerAbstractionLayer {
  constructor() {
    this.brokers = {
      DHAN: createBrokerAdapter('dhan')
    };
    this.activeBroker = 'DHAN';
  }

  async initialize() {
    return true;
  }

  getActiveBroker() {
    return this.brokers[this.activeBroker];
  }

  async healthCheck() {
    const broker = this.getActiveBroker();
    if (!broker || typeof broker.health !== 'function') {
      return { status: 'UNAVAILABLE', message: 'Active broker health check is not available' };
    }

    const health = await broker.health();
    return {
      status: health.ok ? 'HEALTHY' : 'UNHEALTHY',
      activeBroker: this.activeBroker,
      ...health
    };
  }
}

module.exports = new BrokerAbstractionLayer();
