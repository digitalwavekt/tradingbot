const WebSocket = require('ws');
const logger = require('../../utils/logger');

class DhanWebSocketService {
  constructor(config = {}) {
    this.config = config;
    this.ws = null;
    this.wsUrl = config.wsUrl || process.env.DHAN_WS_URL || 'wss://api-feed.dhan.co';
    this.clientId = config.clientId || process.env.DHAN_CLIENT_ID;
    this.accessToken = config.accessToken || process.env.DHAN_ACCESS_TOKEN;
    this.subscriptions = new Map();
    this.connected = false;
  }

  async connect() {
    if (!this.clientId || !this.accessToken) throw new Error('Dhan websocket credentials are required');
    if (this.connected && this.ws) return true;

    const url = `${this.wsUrl}?version=2&token=${encodeURIComponent(this.accessToken)}&clientId=${encodeURIComponent(this.clientId)}&authType=2`;
    await new Promise((resolve, reject) => {
      this.ws = new WebSocket(url);
      this.ws.once('open', () => {
        this.connected = true;
        logger.info('Dhan websocket connected');
        resolve();
      });
      this.ws.once('error', reject);
      this.ws.on('close', () => {
        this.connected = false;
        logger.warn('Dhan websocket disconnected');
      });
      this.ws.on('message', message => this.handleMessage(message));
    });
    return true;
  }

  subscribe(symbols = [], handlers = {}) {
    if (!this.ws || !this.connected) throw new Error('Dhan websocket is not connected');
    const instruments = symbols.map(item => ({
      ExchangeSegment: item.exchangeSegment || item.ExchangeSegment || 'NSE_EQ',
      SecurityId: String(item.securityId || item.SecurityId)
    }));
    for (const instrument of instruments) {
      this.subscriptions.set(`${instrument.ExchangeSegment}:${instrument.SecurityId}`, handlers);
    }
    this.ws.send(JSON.stringify({
      RequestCode: 15,
      InstrumentCount: instruments.length,
      InstrumentList: instruments
    }));
    return true;
  }

  async disconnect() {
    if (this.ws) this.ws.close();
    this.connected = false;
    return true;
  }

  handleMessage(message) {
    for (const handlers of this.subscriptions.values()) {
      if (typeof handlers.onMessage === 'function') handlers.onMessage(message);
    }
  }
}

module.exports = DhanWebSocketService;
