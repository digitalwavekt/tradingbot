const DhanApiClient = require('./DhanApiClient');
const Order = require('../../models/Order');

class DhanOrderService {
  constructor(config = {}) {
    this.client = new DhanApiClient(config);
    this.clientId = this.client.clientId;
  }

  async placeOrder(order) {
    if (!order.correlationId) throw new Error('correlationId/idempotency key is required');
    const existing = await Order.findOne({ broker: 'dhan', correlationId: order.correlationId });
    if (existing) {
      return { duplicate: true, orderId: existing.brokerOrderId, status: existing.status };
    }

    const payload = this.toDhanOrder(order);
    const response = await this.client.request('post', '/orders', payload);
    await Order.create({
      broker: 'dhan',
      brokerOrderId: response.orderId,
      correlationId: order.correlationId,
      symbol: order.symbol,
      securityId: payload.securityId,
      exchangeSegment: payload.exchangeSegment,
      transactionType: payload.transactionType,
      productType: payload.productType,
      orderType: payload.orderType,
      quantity: Number(payload.quantity),
      price: Number(payload.price || 0),
      triggerPrice: Number(payload.triggerPrice || 0),
      status: response.orderStatus || 'TRANSIT',
      mode: order.mode || process.env.TRADING_MODE || 'PAPER',
      rawRequest: payload,
      rawResponse: response
    });
    return response;
  }

  async modifyOrder(orderId, params) {
    const payload = {
      dhanClientId: this.clientId,
      orderId,
      orderType: params.orderType,
      legName: params.legName || '',
      quantity: String(params.quantity || ''),
      price: params.price ?? '',
      disclosedQuantity: params.disclosedQuantity ?? '',
      triggerPrice: params.triggerPrice ?? '',
      validity: params.validity || 'DAY'
    };
    const response = await this.client.request('put', `/orders/${orderId}`, payload);
    await Order.updateOne({ brokerOrderId: orderId }, { status: response.orderStatus, rawResponse: response });
    return response;
  }

  async cancelOrder(orderId) {
    const response = await this.client.request('delete', `/orders/${orderId}`);
    await Order.updateOne({ brokerOrderId: orderId }, { status: response.orderStatus || 'CANCELLED', rawResponse: response });
    return response;
  }

  async getOrderStatus(orderId) {
    return this.client.request('get', `/orders/${orderId}`);
  }

  async getOrderByCorrelationId(correlationId) {
    return this.client.request('get', `/orders/external/${correlationId}`);
  }

  async getOrderBook() {
    return this.client.request('get', '/orders');
  }

  async getTradeBook() {
    return this.client.request('get', '/trades');
  }

  toDhanOrder(order) {
    return {
      dhanClientId: this.clientId,
      correlationId: order.correlationId,
      transactionType: order.transactionType,
      exchangeSegment: order.exchangeSegment || 'NSE_EQ',
      productType: order.productType || 'INTRADAY',
      orderType: order.orderType || 'LIMIT',
      validity: order.validity || 'DAY',
      securityId: String(order.securityId),
      quantity: String(order.quantity),
      disclosedQuantity: order.disclosedQuantity ?? '',
      price: order.price ?? '',
      triggerPrice: order.triggerPrice ?? '',
      afterMarketOrder: Boolean(order.afterMarketOrder),
      amoTime: order.amoTime || '',
      boProfitValue: order.boProfitValue || '',
      boStopLossValue: order.boStopLossValue || ''
    };
  }
}

module.exports = DhanOrderService;
