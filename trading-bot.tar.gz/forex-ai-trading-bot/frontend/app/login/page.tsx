'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { SystemStatus } from '@/components/system-status';
import { useAuthStore } from '@/hooks/useAuth';
import { AlertTriangle, BarChart3, LockKeyhole, ShieldCheck, TrendingUp, Activity } from 'lucide-react';

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const login = useAuthStore((state) => state.login);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const normalizedEmail = email.trim().toLowerCase();

    if (!emailPattern.test(normalizedEmail)) {
      setError('Enter a valid email address.');
      return;
    }

    if (password.length < 12) {
      setError('Password must be at least 12 characters.');
      return;
    }

    setIsLoading(true);

    try {
      await login(normalizedEmail, password);
      router.push('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-950">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-md bg-blue-600 text-white">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="text-base font-semibold text-slate-950">NiveshAI Guard</div>
              <div className="text-xs text-slate-500">AI Trading Risk Console</div>
            </div>
          </div>
          <div className="hidden sm:block">
            <SystemStatus />
          </div>
        </div>
      </header>

      <main className="mx-auto grid min-h-[calc(100vh-4rem)] max-w-7xl gap-0 px-4 py-8 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:px-8">
        <section className="flex flex-col justify-center border-b border-slate-200 py-10 lg:border-b-0 lg:border-r lg:pr-12">
          <div className="inline-flex w-fit items-center gap-2 rounded-md bg-blue-50 px-3 py-2 text-sm font-semibold text-blue-700 ring-1 ring-blue-100">
            <ShieldCheck className="h-4 w-4" />
            Blue-white-black command system
          </div>
          <h1 className="mt-6 max-w-2xl text-4xl font-semibold leading-tight text-slate-950 sm:text-5xl">
            Clean trading controls that are visible, fast, and risk-first.
          </h1>
          <p className="mt-5 max-w-xl text-base leading-7 text-slate-600">
            Monitor broker status, AI signals, backtests, open trades, and admin approvals from one clear operating dashboard.
          </p>

          <div className="mt-6 sm:hidden">
            <SystemStatus />
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {[
              ['Mode', 'Learning', Activity],
              ['Live orders', 'Locked', LockKeyhole],
              ['Risk gate', 'Active', TrendingUp]
            ].map(([label, value, Icon]) => {
              const StatusIcon = Icon as typeof ShieldCheck;
              return (
                <div key={label as string} className="rounded-lg border border-slate-200 bg-slate-50 p-4">
                  <StatusIcon className="h-5 w-5 text-blue-600" />
                  <div className="mt-4 text-xs font-semibold uppercase tracking-wide text-slate-500">{label as string}</div>
                  <div className="mt-1 text-xl font-semibold text-slate-950">{value as string}</div>
                </div>
              );
            })}
          </div>

          <div className="mt-8 rounded-lg bg-slate-950 p-5 text-white">
            <div className="text-sm font-semibold text-blue-200">System preview</div>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <div>
                <div className="text-xs text-slate-400">Signals</div>
                <div className="mt-1 text-2xl font-semibold">24</div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Risk usage</div>
                <div className="mt-1 text-2xl font-semibold text-blue-300">12%</div>
              </div>
              <div>
                <div className="text-xs text-slate-400">API health</div>
                <div className="mt-1 text-2xl font-semibold text-emerald-300">OK</div>
              </div>
            </div>
          </div>
        </section>

        <section className="flex items-center justify-center py-10 lg:pl-12">
          <div className="w-full max-w-md rounded-lg border border-slate-200 bg-white p-6 shadow-[0_20px_70px_rgba(15,23,42,0.12)]">
            <div className="flex h-12 w-12 items-center justify-center rounded-md bg-blue-600 text-white">
              <LockKeyhole className="h-5 w-5" />
            </div>
            <h2 className="mt-5 text-2xl font-semibold text-slate-950">Secure Login</h2>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Sign in to open the trading dashboard and manage protected workflows.
            </p>

            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-slate-700">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11 w-full rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                  placeholder="admin@example.com"
                  autoComplete="email"
                  inputMode="email"
                  maxLength={254}
                  pattern="[^\s@]+@[^\s@]+\.[^\s@]+"
                  required
                />
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-medium text-slate-700">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11 w-full rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                  placeholder="Enter password"
                  autoComplete="current-password"
                  required
                  minLength={12}
                  maxLength={128}
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                size="lg"
                disabled={isLoading}
              >
                {isLoading ? 'Authenticating...' : 'Login'}
              </Button>
            </form>

            <div className="mt-5 rounded-md border border-amber-200 bg-amber-50 p-3">
              <p className="flex items-start gap-2 text-xs leading-5 text-amber-800">
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                Trading involves significant risk. Past performance does not guarantee future results.
              </p>
            </div>

            <div className="mt-6 flex items-center gap-2 text-xs text-slate-500">
              <BarChart3 className="h-4 w-4" />
              AI is advisory only. Execution remains risk-gated.
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
